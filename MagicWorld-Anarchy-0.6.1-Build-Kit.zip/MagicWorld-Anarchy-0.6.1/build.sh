#!/usr/bin/env bash
set -euo pipefail
command -v java >/dev/null 2>&1 || { echo 'Java not found. Install JDK 21.' >&2; exit 1; }
command -v mvn >/dev/null 2>&1 || { echo 'Maven not found. Install Apache Maven 3.9+.' >&2; exit 1; }
java -version 2>&1 | grep -q '21\.' || echo 'WARNING: Java 21 is recommended for this build.'
mvn -B clean package
echo "Build completed. JAR: target/MagicWorld-0.6.1.jar"
