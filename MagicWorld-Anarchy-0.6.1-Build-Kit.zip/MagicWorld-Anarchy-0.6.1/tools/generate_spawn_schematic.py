#!/usr/bin/env python3
"""Generate the MagicWorld 1.21.x spawn as a Sponge Schematic v2 file."""
from __future__ import annotations
import gzip, struct, sys
from pathlib import Path

W, H, L = 161, 56, 161
AIR = 'minecraft:air'
palette_names = [AIR]
palette_ids = {AIR: 0}
blocks = bytearray(W * H * L)

def pid(state: str) -> int:
    if state not in palette_ids:
        palette_ids[state] = len(palette_names)
        palette_names.append(state)
    return palette_ids[state]

def idx(x, y, z):
    return (y * L + z) * W + x

def put(x, y, z, state):
    if 0 <= x < W and 0 <= z < L and 0 <= y < H:
        blocks[idx(x, y, z)] = pid(state)

def box(x1,y1,z1,x2,y2,z2,state, hollow=False, wall=1):
    for y in range(y1,y2+1):
        for z in range(z1,z2+1):
            for x in range(x1,x2+1):
                if hollow and x1+wall <= x <= x2-wall and z1+wall <= z <= z2-wall and y1+wall <= y <= y2-wall:
                    continue
                put(x,y,z,state)

def line_x(x1,x2,y,z,state):
    for x in range(min(x1,x2),max(x1,x2)+1): put(x,y,z,state)
def line_z(x,y,z1,z2,state):
    for z in range(min(z1,z2),max(z1,z2)+1): put(x,y,z,state)
def disk(cx,cz,r,y,state):
    rr=r*r
    for z in range(cz-r,cz+r+1):
        for x in range(cx-r,cx+r+1):
            if (x-cx)**2+(z-cz)**2 <= rr: put(x,y,z,state)
def tower(cx,cz,base,height,r=4):
    # Square stone tower with cyan stepped roof and sea-lantern windows.
    box(cx-r,base,cz-r,cx+r,base+height,cz+r,'minecraft:stone_bricks',hollow=True,wall=1)
    for y in range(base+3,base+height-1,5):
        put(cx, y, cz-r, 'minecraft:sea_lantern'); put(cx, y, cz+r, 'minecraft:sea_lantern')
        put(cx-r, y, cz, 'minecraft:sea_lantern'); put(cx+r, y, cz, 'minecraft:sea_lantern')
    for k in range(0,4):
        rad=max(1,r-k)
        box(cx-rad,base+height+k,cz-rad,cx+rad,base+height+k,cz+rad,
            'minecraft:cyan_concrete' if k%2==0 else 'minecraft:light_blue_concrete')
    box(cx-1,base+height+4,cz-1,cx+1,base+height+4,cz+1,'minecraft:sea_lantern')
    put(cx,base+height+5,cz,'minecraft:lightning_rod')

# A broad floating-platform foundation and grassy ground.
for z in range(L):
    for x in range(W):
        put(x,0,z,'minecraft:stone')
        put(x,1,z,'minecraft:dirt')
        put(x,2,z,'minecraft:grass_block')

# Perimeter boundary: low sea wall and four entrance cuts.
for y in range(3,7):
    wall_state = 'minecraft:stone_bricks' if y in (3,6) else 'minecraft:cyan_stained_glass'
    for q in range(4,157):
        put(q,y,4,wall_state); put(q,y,156,wall_state)
        put(4,y,q,wall_state); put(156,y,q,wall_state)
# Four gates interrupt the outer wall.
for x1,x2,z1,z2 in [(74,86,4,5),(74,86,155,156),(4,5,74,86),(155,156,74,86)]:
    box(x1,3,z1,x2,6,z2,AIR)

# Central plaza, concentric rings and radial paths.
disk(80,80,28,3,'minecraft:smooth_quartz')
disk(80,80,25,3,'minecraft:light_blue_concrete')
disk(80,80,22,3,'minecraft:polished_andesite')
disk(80,80,18,3,'minecraft:cyan_concrete')
disk(80,80,15,3,'minecraft:smooth_quartz')
disk(80,80,12,3,'minecraft:light_blue_concrete')
for x in range(52,109):
    put(x,3,80,'minecraft:polished_andesite')
    put(x,3,79,'minecraft:sea_lantern' if x%4==0 else 'minecraft:polished_andesite')
for z in range(52,109):
    put(80,3,z,'minecraft:polished_andesite')
    put(81,3,z,'minecraft:sea_lantern' if z%4==0 else 'minecraft:polished_andesite')
# Walkways connect the square plaza to the southern, eastern and western pavilions.
for z in range(76,85):
    for x in range(4,53): put(x,3,z,'minecraft:polished_andesite')
    for x in range(108,157): put(x,3,z,'minecraft:polished_andesite')
for z in range(107,124):
    for x in range(76,85): put(x,3,z,'minecraft:polished_andesite')
# Decorative spokes
for d in range(19,29):
    for s in (-1,1):
        put(80+s*d,3,80,'minecraft:cyan_concrete')
        put(80,3,80+s*d,'minecraft:cyan_concrete')

# Central crystal monument.
box(76,4,76,84,5,84,'minecraft:quartz_bricks')
box(77,6,77,83,9,83,'minecraft:sea_lantern')
box(78,10,78,82,15,82,'minecraft:cyan_stained_glass')
box(79,16,79,81,20,81,'minecraft:light_blue_stained_glass')
put(80,21,80,'minecraft:diamond_block')
put(80,22,80,'minecraft:lightning_rod')
for x,z in [(74,80),(86,80),(80,74),(80,86)]:
    box(x-1,4,z-1,x+1,7,z+1,'minecraft:sea_lantern')

# Main castle to the north. Floor and outer walls.
box(53,3,18,107,4,59,'minecraft:polished_deepslate')
box(55,5,20,105,15,57,'minecraft:stone_bricks',hollow=True,wall=2)
# cyan upper trim
box(54,15,19,106,16,58,'minecraft:cyan_concrete',hollow=True)
# Grand entrance on south-facing wall
box(76,5,55,84,10,58,AIR)
box(75,5,54,85,5,59,'minecraft:smooth_quartz')
# Castle inner hall
box(65,5,28,95,13,50,'minecraft:quartz_bricks',hollow=True,wall=1)
box(66,5,29,94,5,49,'minecraft:smooth_quartz')
for x in (70,80,90):
    for z in (31,46):
        box(x,6,z,x,12,z,'minecraft:quartz_pillar')
# window lights
for x in (62,98):
    for z in (30,39,48): box(x,8,z,x,11,z,'minecraft:cyan_stained_glass')
# Roof terraces and towers
for cx,cz,h in [(58,23,18),(102,23,18),(58,53,18),(102,53,18)]: tower(cx,cz,5,h,4)
# central taller keep
tower(80,36,5,25,6)
# banners/windows along battlements
for x in range(66,95,4):
    put(x,13,20,'minecraft:sea_lantern'); put(x,13,57,'minecraft:sea_lantern')
# stairs toward plaza
for i in range(8):
    z=60+i
    box(76,3+i//3,z,84,3+i//3,z,'minecraft:stone_brick_stairs')

# Four themed service buildings around the plaza.
def shop_building(cx,cz,label_color='minecraft:light_blue_concrete'):
    box(cx-10,3,cz-8,cx+10,4,cz+8,'minecraft:polished_andesite')
    box(cx-9,5,cz-7,cx+9,11,cz+7,'minecraft:stone_bricks',hollow=True,wall=1)
    # front door facing center (assumes approach from nearer central plaza)
    if cz < 80: box(cx-2,5,cz+7,cx+2,8,cz+7,AIR)
    else: box(cx-2,5,cz-7,cx+2,8,cz-7,AIR)
    box(cx-11,11,cz-9,cx+11,12,cz+9,label_color,hollow=True)
    box(cx-7,12,cz-5,cx+7,14,cz+5,'minecraft:cyan_concrete')
    box(cx-4,14,cz-3,cx+4,15,cz+3,'minecraft:sea_lantern')
    for x in (cx-7,cx+7):
        for z in (cz-5,cz+5):
            box(x,5,z,x,9,z,'minecraft:quartz_pillar')
    for x in range(cx-5,cx+6,5):
        put(x,9,cz-7,'minecraft:sea_lantern')
        put(x,9,cz+7,'minecraft:sea_lantern')

shop_building(31,80,'minecraft:cyan_concrete')
shop_building(129,80,'minecraft:light_blue_concrete')
shop_building(80,129,'minecraft:blue_concrete')

# Marked destinations: colored pads, archways, and labels made from block patterns.
def portal_arch(cx,cz,axis='z',color='minecraft:cyan_stained_glass'):
    if axis=='z':
        box(cx-5,3,cz,cx-4,12,cz+1,'minecraft:quartz_bricks')
        box(cx+4,3,cz,cx+5,12,cz+1,'minecraft:quartz_bricks')
        box(cx-5,12,cz,cx+5,13,cz+1,'minecraft:quartz_bricks')
        box(cx-3,4,cz,cx+3,11,cz,color)
    else:
        box(cx,3,cz-5,cx+1,12,cz-4,'minecraft:quartz_bricks')
        box(cx,3,cz+4,cx+1,12,cz+5,'minecraft:quartz_bricks')
        box(cx,12,cz-5,cx+1,13,cz+5,'minecraft:quartz_bricks')
        box(cx,4,cz-3,cx,11,cz+3,color)
for cx,cz,axis in [(80,48,'z'),(80,112,'z'),(48,80,'x'),(112,80,'x')]:
    portal_arch(cx,cz,axis)

# Small fountains in four corners of the central square.
for cx,cz in [(55,55),(105,55),(55,105),(105,105)]:
    disk(cx,cz,5,3,'minecraft:stone_bricks')
    disk(cx,cz,3,4,'minecraft:water')
    box(cx-1,5,cz-1,cx+1,7,cz+1,'minecraft:sea_lantern')

# Gardens, trees, lamps and benches inside the compound.
for cx,cz in [(20,20),(140,20),(20,140),(140,140),(25,55),(135,55),(25,105),(135,105)]:
    disk(cx,cz,6,3,'minecraft:moss_block')
    box(cx-1,4,cz-1,cx+1,9,cz+1,'minecraft:oak_log')
    for y,r in [(7,3),(9,2),(11,1)]: disk(cx,cz,r,y,'minecraft:azalea_leaves')
for x,z in [(43,43),(117,43),(43,117),(117,117),(80,12),(80,148),(12,80),(148,80)]:
    box(x-1,3,z-1,x+1,5,z+1,'minecraft:quartz_pillar')
    box(x-2,6,z-2,x+2,6,z+2,'minecraft:sea_lantern')
    box(x-2,7,z-2,x+2,7,z+2,'minecraft:cyan_stained_glass')

# Decorative floating platforms outside the walls, with crystal tips.
for cx,cz in [(28,28),(132,28),(28,132),(132,132)]:
    disk(cx,cz,7,24,'minecraft:stone_bricks')
    disk(cx,cz,5,25,'minecraft:cyan_concrete')
    box(cx-1,26,cz-1,cx+1,30,cz+1,'minecraft:cyan_stained_glass')
    put(cx,31,cz,'minecraft:sea_lantern')

# Palette and binary NBT writer (big-endian, Sponge Schematic v2).
def tag(name, typ, payload):
    n=name.encode('utf-8')
    return struct.pack('>BH',typ,len(n))+n+payload
def t_int(name,v): return tag(name,3,struct.pack('>i',v))
def t_short(name,v): return tag(name,2,struct.pack('>h',v))
def t_string(name,v):
    b=v.encode('utf-8'); return tag(name,8,struct.pack('>H',len(b))+b)
def t_byte_array(name,b): return tag(name,7,struct.pack('>i',len(b))+bytes(b))
def t_int_array(name,vals): return tag(name,11,struct.pack('>i',len(vals))+b''.join(struct.pack('>i',v) for v in vals))
def t_list_empty_compound(name): return tag(name,9,struct.pack('>bi',10,0))

def write_schematic(path: Path):
    palette_payload=b''.join(t_int(n,i) for i,n in enumerate(palette_names))+b'\x00'
    palette_tag=tag('Palette',10,palette_payload)
    metadata_tag=tag('Metadata',10,b'\x00')
    body=(t_int('Version',2)+t_int('DataVersion',4189)+t_short('Width',W)+t_short('Height',H)+t_short('Length',L)
          +t_int_array('Offset',[0,0,0])+palette_tag+t_int('PaletteMax',len(palette_names))
          +t_byte_array('BlockData',blocks)+t_list_empty_compound('BlockEntities')+t_list_empty_compound('Entities')+metadata_tag+b'\x00')
    root=struct.pack('>BH',10,9)+b'Schematic'+body
    with gzip.open(path,'wb',compresslevel=9) as f: f.write(root)

out=Path(sys.argv[1] if len(sys.argv)>1 else 'MagicWorld-Spawn-1.21.schem')
write_schematic(out)
print(f'Created {out} | {W}x{H}x{L} | palette={len(palette_names)} | compressed={out.stat().st_size:,} bytes')
