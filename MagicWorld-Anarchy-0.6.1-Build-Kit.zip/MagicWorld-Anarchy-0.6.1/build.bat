@echo off
setlocal
where java >nul 2>nul || (echo Java not found. Install JDK 21. & exit /b 1)
where mvn >nul 2>nul || (echo Maven not found. Install Apache Maven 3.9+ and add mvn to PATH. & exit /b 1)
java -version 2>&1 | findstr /C:"21." >nul || echo WARNING: Java 21 is recommended for this build.
mvn -B clean package
if errorlevel 1 exit /b %errorlevel%
echo.
echo Build completed. JAR: target\MagicWorld-0.6.1.jar
endlocal
