package ru.magicworld;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.Monster;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ThreadLocalRandom;

public final class MagicWorld extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final Map<UUID, BukkitTask> pending = new HashMap<>();
    private final Map<UUID, Long> rtpCooldown = new HashMap<>();
    private final Set<UUID> authorizedSpawnExit = new HashSet<>();
    private final Map<UUID, TalismanType> selectedType = new HashMap<>();
    private final Map<UUID, TpaRequest> tpaRequests = new HashMap<>();
    private final Set<String> specialTntBlocks = new HashSet<>();
    private File dataFile;
    private YamlConfiguration data;

    private record TpaRequest(UUID requester, long createdAt) {}

    private NamespacedKey sphereKey, specialTntKey;
    private NamespacedKey wardKey, furyKey, swiftKey, vitalityKey, auctionIdKey;

    private enum TalismanType {
        WARD("Защита", Material.SHIELD, "Сопротивление после спасения тотемом", PotionEffectType.RESISTANCE, 40, 2),
        FURY("Ярость", Material.IRON_SWORD, "Сила после спасения тотемом", PotionEffectType.STRENGTH, 60, 1),
        SWIFT("Стремительность", Material.SUGAR, "Скорость после спасения тотемом", PotionEffectType.SPEED, 100, 2),
        VITALITY("Живучесть", Material.GOLDEN_APPLE, "Поглощение после спасения тотемом", PotionEffectType.ABSORPTION, 100, 2);

        final String title;
        final Material icon;
        final String description;
        final PotionEffectType effect;
        final int durationPerLevel;
        final int maxAmplifier;
        TalismanType(String title, Material icon, String description, PotionEffectType effect,
                     int durationPerLevel, int maxAmplifier) {
            this.title = title; this.icon = icon; this.description = description;
            this.effect = effect; this.durationPerLevel = durationPerLevel; this.maxAmplifier = maxAmplifier;
        }
    }

    private static final class TalismanMenu implements InventoryHolder {
        private final Inventory inventory;
        TalismanMenu() { inventory = Bukkit.createInventory(this, 27, ChatColor.DARK_AQUA + "Заточка талисмана"); }
        @Override public Inventory getInventory() { return inventory; }
    }

    private static final class AuctionMenu implements InventoryHolder {
        private final Inventory inventory;
        private final int page;
        AuctionMenu(int page) { this.page = Math.max(0, page); inventory = Bukkit.createInventory(this, 54, ChatColor.DARK_AQUA + "Аукцион MagicWorld · " + (this.page + 1)); }
        int page() { return page; }
        @Override public Inventory getInventory() { return inventory; }
    }

    private static final class ShopMenu implements InventoryHolder {
        private final Inventory inventory;
        ShopMenu() { inventory = Bukkit.createInventory(this, 27, ChatColor.DARK_AQUA + "Магазин MagicWorld"); }
        @Override public Inventory getInventory() { return inventory; }
    }

    @Override public void onEnable() {
        saveDefaultConfig();
        loadPlayerData();
        specialTntBlocks.addAll(data.getStringList("special-tnt-blocks"));
        sphereKey = new NamespacedKey(this, "magic_sphere");
        specialTntKey = new NamespacedKey(this, "magic_tnt");
        wardKey = new NamespacedKey(this, "talisman_ward");
        furyKey = new NamespacedKey(this, "talisman_fury");
        swiftKey = new NamespacedKey(this, "talisman_swift");
        vitalityKey = new NamespacedKey(this, "talisman_vitality");
        auctionIdKey = new NamespacedKey(this, "auction_id");

        String spawnWorld = getConfig().getString("spawn.world", "mw_spawn");
        if (Bukkit.getWorld(spawnWorld) == null) {
            World created = Bukkit.createWorld(new WorldCreator(spawnWorld).environment(World.Environment.NORMAL));
            if (created == null) getLogger().warning("Не удалось автоматически создать мир спавна " + spawnWorld);
            else getLogger().info("Создан отдельный мир спавна: " + spawnWorld);
        }

        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("mw", "setspawn", "spawn", "rtp", "talisman", "balance", "pay", "sethome", "home", "delhome", "tpa", "tpaccept", "tpdeny", "setwarp", "delwarp", "warp", "ec", "repair", "shop", "ah", "clan", "daily", "quest")) {
            PluginCommand c = getCommand(name);
            if (c != null) { c.setExecutor(this); c.setTabCompleter(this); }
        }
        getLogger().info("MagicWorld 0.6.1 enabled.");
    }

    @Override public void onDisable() {
        pending.values().forEach(BukkitTask::cancel);
        pending.clear();
        savePlayerData();
    }

    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
    private String msg(String key) {
        String prefix = getConfig().getString("messages.prefix", "&b&lMagicWorld &8» &f");
        return color(prefix + getConfig().getString("messages." + key, "&cMissing message: " + key));
    }
    private void tell(Player p, String key) { p.sendMessage(msg(key)); }
    private void tell(Player p, String key, String token, String value) {
        p.sendMessage(msg(key).replace("{" + token + "}", value));
    }
    private boolean admin(Player p) {
        if (p.hasPermission("magicworld.admin")) return true;
        tell(p, "no-permission"); return false;
    }
    private boolean playerOnly(CommandSender s) {
        if (s instanceof Player) return true;
        s.sendMessage("This command can only be used in-game."); return false;
    }

    private Location spawnLocation() {
        World w = Bukkit.getWorld(getConfig().getString("spawn.world", "mw_spawn"));
        if (w == null) return null;
        return new Location(w, getConfig().getDouble("spawn.x", 0.5),
                getConfig().getDouble("spawn.y", 80), getConfig().getDouble("spawn.z", 0.5),
                (float)getConfig().getDouble("spawn.yaw", 0), (float)getConfig().getDouble("spawn.pitch", 0));
    }
    private boolean inSpawn(Player p) {
        return p.getWorld().getName().equalsIgnoreCase(getConfig().getString("spawn.world", "mw_spawn"));
    }

    private void cancelPending(Player p, boolean notify) {
        BukkitTask task = pending.remove(p.getUniqueId());
        if (task != null) {
            task.cancel();
            if (notify) tell(p, "teleport-cancel");
        }
    }

    private void safeTeleport(Player p, Location destination, boolean isRtpExit) {
        cancelPending(p, false);
        int delay = Math.max(0, getConfig().getInt("rtp.delay-seconds", 3));
        Runnable action = () -> {
            if (!p.isOnline()) return;
            if (isRtpExit && inSpawn(p)) authorizedSpawnExit.add(p.getUniqueId());
            p.teleportAsync(destination).whenComplete((ok, error) ->
                    Bukkit.getScheduler().runTask(this, () -> {
                        authorizedSpawnExit.remove(p.getUniqueId());
                        if (error != null) {
                            getLogger().warning("Teleport failed for " + p.getName() + ": " + error.getMessage());
                            if (p.isOnline()) tell(p, "rtp-failed");
                            return;
                        }
                        if (Boolean.TRUE.equals(ok) && p.isOnline()) tell(p, "teleport-done");
                    }));
        };
        if (delay == 0) { action.run(); return; }
        tell(p, "teleport-start", "seconds", String.valueOf(delay));
        BukkitTask task = Bukkit.getScheduler().runTaskLater(this, () -> {
            pending.remove(p.getUniqueId());
            action.run();
        }, delay * 20L);
        pending.put(p.getUniqueId(), task);
    }

    @EventHandler public void onMove(PlayerMoveEvent e) {
        if (!getConfig().getBoolean("rtp.cancel-on-move", true) || e.getTo() == null) return;
        if (e.getFrom().getBlockX() != e.getTo().getBlockX()
                || e.getFrom().getBlockY() != e.getTo().getBlockY()
                || e.getFrom().getBlockZ() != e.getTo().getBlockZ()) cancelPending(e.getPlayer(), true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        if (!e.getFrom().getWorld().getName().equalsIgnoreCase(getConfig().getString("spawn.world", "mw_spawn"))) return;
        if (e.getTo() == null || e.getTo().getWorld() == null) return;
        boolean leavingSpawn = !e.getTo().getWorld().getName().equalsIgnoreCase(getConfig().getString("spawn.world", "mw_spawn"));
        if (leavingSpawn && !authorizedSpawnExit.remove(e.getPlayer().getUniqueId())) {
            e.setCancelled(true);
            tell(e.getPlayer(), "only-rtp-exit");
        }
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) {
        cancelPending(e.getPlayer(), false);
        authorizedSpawnExit.remove(e.getPlayer().getUniqueId());
        selectedType.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        if (!e.getPlayer().hasPlayedBefore()) {
            Location spawn = spawnLocation();
            if (spawn != null) e.getPlayer().teleportAsync(spawn);
        }
    }

    @EventHandler public void onRespawn(PlayerRespawnEvent e) {
        if (e.getPlayer().getWorld().getName().equalsIgnoreCase(getConfig().getString("spawn.world", "mw_spawn"))) {
            Location spawn = spawnLocation();
            if (spawn != null) e.setRespawnLocation(spawn);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (inSpawn(e.getPlayer()) && getConfig().getBoolean("spawn-protection.enabled", true)
                && !getConfig().getBoolean("spawn-protection.block-break", false)
                && !e.getPlayer().hasPermission("magicworld.admin")) e.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (inSpawn(e.getPlayer()) && getConfig().getBoolean("spawn-protection.enabled", true)
                && !getConfig().getBoolean("spawn-protection.block-place", false)
                && !e.getPlayer().hasPermission("magicworld.admin")) e.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && inSpawn(p)
                && getConfig().getBoolean("spawn-protection.enabled", true)
                && !getConfig().getBoolean("spawn-protection.damage", false)) e.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (e.getEntity() instanceof Player victim && inSpawn(victim)
                && !getConfig().getBoolean("spawn-protection.pvp", false)) e.setCancelled(true);
        if (e.getDamager() instanceof Player attacker && inSpawn(attacker)
                && !getConfig().getBoolean("spawn-protection.pvp", false)) e.setCancelled(true);
    }

    // -------- Magic spheres and enhanced vanilla totems --------

    private ItemStack createSphere(int amount) {
        ItemStack item = new ItemStack(Material.AMETHYST_SHARD, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color("&b&lМагическая сфера"));
        meta.setLore(List.of(color("&7Ресурс для улучшения талисманов."),
                color("&8MagicWorld • Заточка")));
        meta.getPersistentDataContainer().set(sphereKey, PersistentDataType.BYTE, (byte)1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isSphere(ItemStack item) {
        if (item == null || item.getType() != Material.AMETHYST_SHARD || !item.hasItemMeta()) return false;
        Byte marker = item.getItemMeta().getPersistentDataContainer().get(sphereKey, PersistentDataType.BYTE);
        return marker != null && marker == (byte)1;
    }

    private NamespacedKey key(TalismanType type) {
        return switch (type) {
            case WARD -> wardKey;
            case FURY -> furyKey;
            case SWIFT -> swiftKey;
            case VITALITY -> vitalityKey;
        };
    }
    private int level(ItemStack totem, TalismanType type) {
        if (totem == null || totem.getType() != Material.TOTEM_OF_UNDYING || !totem.hasItemMeta()) return 0;
        Integer value = totem.getItemMeta().getPersistentDataContainer().get(key(type), PersistentDataType.INTEGER);
        return value == null ? 0 : Math.max(0, value);
    }
    private boolean isTalisman(ItemStack item) {
        if (item == null || item.getType() != Material.TOTEM_OF_UNDYING || !item.hasItemMeta()) return false;
        for (TalismanType type : TalismanType.values()) if (level(item, type) > 0) return true;
        return false;
    }

    private void updateTotemLore(ItemStack totem) {
        if (totem == null || totem.getType() != Material.TOTEM_OF_UNDYING) return;
        ItemMeta meta = totem.getItemMeta();
        List<String> lore = new ArrayList<>();
        lore.add(color("&8Талисман MagicWorld"));
        lore.add(color("&7Улучшения:"));
        boolean any = false;
        for (TalismanType type : TalismanType.values()) {
            int lvl = level(totem, type);
            if (lvl > 0) {
                any = true;
                lore.add(color("&b" + type.title + " " + roman(lvl)));
            }
        }
        if (!any) lore.add(color("&7Ещё не зачарован."));
        lore.add(color("&8Улучшается магическими сферами"));
        meta.setLore(lore);
        totem.setItemMeta(meta);
    }

    private String roman(int value) {
        return switch (value) { case 1 -> "I"; case 2 -> "II"; case 3 -> "III"; case 4 -> "IV"; case 5 -> "V"; default -> String.valueOf(value); };
    }

    private int countSpheres(Player p) {
        int count = 0;
        for (ItemStack item : p.getInventory().getStorageContents()) if (isSphere(item)) count += item.getAmount();
        return count;
    }
    private void consumeSpheres(Player p, int amount) {
        int left = amount;
        ItemStack[] contents = p.getInventory().getStorageContents();
        for (int i = 0; i < contents.length && left > 0; i++) {
            ItemStack item = contents[i];
            if (!isSphere(item)) continue;
            int take = Math.min(left, item.getAmount());
            item.setAmount(item.getAmount() - take);
            left -= take;
            if (item.getAmount() <= 0) contents[i] = null;
        }
        p.getInventory().setStorageContents(contents);
    }

    private int configuredValue(String path, int index, int fallback) {
        List<Integer> list = getConfig().getIntegerList(path);
        return list.size() > index ? list.get(index) : fallback;
    }

    private void openTalismanMenu(Player p) {
        TalismanMenu menu = new TalismanMenu();
        renderMenu(p, menu);
        p.openInventory(menu.getInventory());
        tell(p, "talisman-open");
    }

    private void renderMenu(Player p, TalismanMenu menu) {
        Inventory inv = menu.getInventory();
        inv.clear();
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.setDisplayName(" ");
        filler.setItemMeta(fillerMeta);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        TalismanType selected = selectedType.getOrDefault(p.getUniqueId(), TalismanType.WARD);
        ItemStack held = p.getInventory().getItemInMainHand();
        for (TalismanType type : TalismanType.values()) {
            int slot = switch (type) { case WARD -> 10; case FURY -> 12; case SWIFT -> 14; case VITALITY -> 16; };
            int lvl = level(held, type);
            ItemStack icon = new ItemStack(type.icon);
            ItemMeta meta = icon.getItemMeta();
            meta.setDisplayName(color((type == selected ? "&a▶ " : "&b") + type.title));
            meta.setLore(List.of(color("&7" + type.description),
                    color("&7Текущий уровень: &b" + (lvl == 0 ? "нет" : roman(lvl))),
                    color(type == selected ? "&aВыбрано" : "&eНажми, чтобы выбрать")));
            icon.setItemMeta(meta);
            inv.setItem(slot, icon);
        }

        ItemStack upgrade = new ItemStack(Material.ANVIL);
        ItemMeta upMeta = upgrade.getItemMeta();
        upMeta.setDisplayName(color("&a&lУЛУЧШИТЬ ТАЛИСМАН"));
        int current = level(held, selected);
        int nextIndex = Math.min(current, 4);
        int cost = configuredValue("talismans.costs", nextIndex, nextIndex + 1);
        int chance = configuredValue("talismans.chances", nextIndex, Math.max(10, 100 - nextIndex * 15));
        upMeta.setLore(List.of(
                color("&7Выбрано: &b" + selected.title),
                color("&7Следующий уровень: &b" + roman(current + 1)),
                color("&7Стоимость: &b" + cost + " сфер"),
                color("&7Шанс успеха: &b" + chance + "%"),
                color("&8При неудаче тотем сохранится.")));
        upgrade.setItemMeta(upMeta);
        inv.setItem(22, upgrade);

        ItemStack info = new ItemStack(Material.TOTEM_OF_UNDYING);
        ItemMeta infoMeta = info.getItemMeta();
        infoMeta.setDisplayName(color("&eТотем в основной руке"));
        infoMeta.setLore(List.of(color("&7Для заточки возьми тотем в руку."),
                color("&7Магических сфер: &b" + countSpheres(p)),
                color("&7Талисман остаётся обычным тотемом.")));
        info.setItemMeta(infoMeta);
        inv.setItem(4, info);
    }

    private void upgradeTalisman(Player p) {
        ItemStack held = p.getInventory().getItemInMainHand();
        if (held.getType() != Material.TOTEM_OF_UNDYING) { tell(p, "talisman-need-totem"); return; }
        TalismanType type = selectedType.getOrDefault(p.getUniqueId(), TalismanType.WARD);
        int current = level(held, type);
        int max = Math.max(1, getConfig().getInt("talismans.max-level", 5));
        if (current >= max) { tell(p, "talisman-max"); return; }
        int index = current;
        int cost = configuredValue("talismans.costs", index, index + 1);
        int chance = Math.max(0, Math.min(100, configuredValue("talismans.chances", index, Math.max(10, 100-index*15))));
        if (countSpheres(p) < cost) { tell(p, "talisman-need-spheres", "amount", String.valueOf(cost)); return; }
        consumeSpheres(p, cost);

        if (ThreadLocalRandom.current().nextInt(100) < chance) {
            ItemMeta meta = held.getItemMeta();
            meta.getPersistentDataContainer().set(key(type), PersistentDataType.INTEGER, current + 1);
            held.setItemMeta(meta);
            updateTotemLore(held);
            tell(p, "talisman-success", "type", type.title);
            // The level is appended separately because the message uses two substitutions.
            p.sendMessage(color("&bMagicWorld &8» &7Новый уровень: &b" + roman(current + 1)));
        } else {
            tell(p, "talisman-fail");
        }
        if (p.getOpenInventory().getTopInventory().getHolder() instanceof TalismanMenu menu) renderMenu(p, menu);
        p.updateInventory();
    }

    @EventHandler public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!(e.getView().getTopInventory().getHolder() instanceof TalismanMenu menu)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getRawSlot();
        TalismanType type = switch (slot) {
            case 10 -> TalismanType.WARD;
            case 12 -> TalismanType.FURY;
            case 14 -> TalismanType.SWIFT;
            case 16 -> TalismanType.VITALITY;
            default -> null;
        };
        if (type != null) {
            selectedType.put(p.getUniqueId(), type);
            renderMenu(p, menu);
        } else if (slot == 22) {
            upgradeTalisman(p);
        }
    }
    @EventHandler public void onMenuDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof TalismanMenu
                || e.getView().getTopInventory().getHolder() instanceof ShopMenu
                || e.getView().getTopInventory().getHolder() instanceof AuctionMenu) e.setCancelled(true);
    }

    @EventHandler public void onAuctionMenuClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!(e.getView().getTopInventory().getHolder() instanceof AuctionMenu menu)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getRawSlot();
        if (slot == 45) { openAuctionMenu(p, Math.max(0, menu.page() - 1)); return; }
        if (slot == 53) { openAuctionMenu(p, menu.page() + 1); return; }
        if (slot < 0 || slot >= 45) return;
        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        String id = clicked.getItemMeta().getPersistentDataContainer().get(auctionIdKey, PersistentDataType.STRING);
        if (id == null) return;
        buyAuctionLot(p, id);
        openAuctionMenu(p, menu.page());
    }

    @EventHandler public void onShopClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!(e.getView().getTopInventory().getHolder() instanceof ShopMenu)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        Material material = switch (e.getRawSlot()) {
            case 10 -> Material.ENDER_PEARL;
            case 12 -> Material.GOLDEN_APPLE;
            case 14 -> Material.DIAMOND;
            case 16 -> Material.EXPERIENCE_BOTTLE;
            case 22 -> Material.TOTEM_OF_UNDYING;
            default -> null;
        };
        if (material == null) return;
        int amount = material == Material.TOTEM_OF_UNDYING ? 1 : 8;
        double price = getConfig().getDouble("shop.prices." + material.name().toLowerCase(Locale.ROOT), 100.0);
        if (getBalance(p.getUniqueId()) + 0.0001 < price) {
            p.sendMessage(color("&bMagicWorld &8» &cНедостаточно средств. Нужно: &b" + money(price)));
            return;
        }
        setBalance(p.getUniqueId(), getBalance(p.getUniqueId()) - price);
        ItemStack purchase = new ItemStack(material, amount);
        Map<Integer, ItemStack> overflow = p.getInventory().addItem(purchase);
        overflow.values().forEach(item -> p.getWorld().dropItemNaturally(p.getLocation(), item));
        p.sendMessage(color("&bMagicWorld &8» &aПокупка: &b" + amount + "x " + material.name() + " &7за &b" + money(price)));
        savePlayerData();
        p.updateInventory();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onResurrect(EntityResurrectEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        ItemStack used = null;
        ItemStack main = p.getInventory().getItemInMainHand();
        ItemStack off = p.getInventory().getItemInOffHand();
        if (main.getType() == Material.TOTEM_OF_UNDYING && isTalisman(main)) used = main.clone();
        else if (off.getType() == Material.TOTEM_OF_UNDYING && isTalisman(off)) used = off.clone();
        if (used == null) return;

        Map<TalismanType, Integer> levels = new EnumMap<>(TalismanType.class);
        for (TalismanType type : TalismanType.values()) {
            int lvl = level(used, type);
            if (lvl > 0) levels.put(type, lvl);
        }
        Bukkit.getScheduler().runTask(this, () -> {
            if (!p.isOnline()) return;
            for (Map.Entry<TalismanType, Integer> entry : levels.entrySet()) {
                TalismanType type = entry.getKey();
                int lvl = entry.getValue();
                int amplifier = Math.min(lvl - 1, type.maxAmplifier);
                int duration = type.durationPerLevel * lvl;
                p.addPotionEffect(new PotionEffect(type.effect, duration, amplifier, true, true, true));
            }
            p.sendMessage(color("&b&lMagicWorld &8» &dТалисман активирован!"));
        });
    }

    // -------- Magic sphere drops from hostile mobs --------

    @EventHandler(priority = EventPriority.NORMAL)
    public void onMonsterDeath(EntityDeathEvent e) {
        if (!(e.getEntity() instanceof Monster)) return;
        Player killer = e.getEntity().getKiller();
        if (killer == null || e.getEntity().getWorld().getName().equalsIgnoreCase(getConfig().getString("spawn.world", "mw_spawn"))) return;
        String day = java.time.LocalDate.now().toString();
        if (!day.equals(data.getString("quests." + killer.getUniqueId() + ".day", ""))) {
            data.set("quests." + killer.getUniqueId() + ".day", day);
            data.set("quests." + killer.getUniqueId() + ".kills", 0);
            data.set("quests." + killer.getUniqueId() + ".claimed", false);
        }
        data.set("quests." + killer.getUniqueId() + ".kills", data.getInt("quests." + killer.getUniqueId() + ".kills", 0) + 1);
        savePlayerData();
        if (!getConfig().getBoolean("sphere-drops.enabled", true)) return;
        double chance = Math.max(0.0, Math.min(1.0, getConfig().getDouble("sphere-drops.chance", 0.08)));
        if (ThreadLocalRandom.current().nextDouble() >= chance) return;
        int max = Math.max(1, Math.min(8, getConfig().getInt("sphere-drops.max-amount", 2)));
        int amount = ThreadLocalRandom.current().nextInt(1, max + 1);
        e.getDrops().add(createSphere(amount));
    }

    // -------- Special TNT: tagged item survives restarts only after placement as a block --------

    private String blockKey(Location location) {
        return location.getWorld().getName() + ":" + location.getBlockX() + ":" + location.getBlockY() + ":" + location.getBlockZ();
    }

    private void persistSpecialTntBlocks() {
        data.set("special-tnt-blocks", new ArrayList<>(specialTntBlocks));
        savePlayerData();
    }

    private ItemStack createMagicTnt(int amount) {
        ItemStack item = new ItemStack(Material.TNT, Math.max(1, Math.min(64, amount)));
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color("&b&lМагический TNT"));
        meta.setLore(List.of(color("&7Усиленный заряд MagicWorld"), color("&7Радиус: &b" + getConfig().getDouble("special-tnt.power", 5.0)), color("&8Особый предмет сервера")));
        meta.getPersistentDataContainer().set(specialTntKey, PersistentDataType.BYTE, (byte)1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isMagicTnt(ItemStack item) {
        if (item == null || item.getType() != Material.TNT || !item.hasItemMeta()) return false;
        Byte marker = item.getItemMeta().getPersistentDataContainer().get(specialTntKey, PersistentDataType.BYTE);
        return marker != null && marker == (byte)1;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void markMagicTntPlacement(BlockPlaceEvent e) {
        if (e.getBlockPlaced().getType() == Material.TNT && isMagicTnt(e.getItemInHand())) {
            specialTntBlocks.add(blockKey(e.getBlockPlaced().getLocation()));
            persistSpecialTntBlocks();
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void clearMarkedTntOnBreak(BlockBreakEvent e) {
        if (e.getBlock().getType() == Material.TNT && specialTntBlocks.remove(blockKey(e.getBlock().getLocation())))
            persistSpecialTntBlocks();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void markMagicTntPriming(EntitySpawnEvent e) {
        if (!(e.getEntity() instanceof TNTPrimed tnt)) return;
        String key = blockKey(tnt.getLocation());
        if (specialTntBlocks.remove(key)) {
            tnt.getPersistentDataContainer().set(specialTntKey, PersistentDataType.BYTE, (byte)1);
            persistSpecialTntBlocks();
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void magicTntExplosion(EntityExplodeEvent e) {
        if (!(e.getEntity() instanceof TNTPrimed tnt)) return;
        // Любой TNT полностью заблокирован на защищённом спавне.
        if (tnt.getWorld().getName().equalsIgnoreCase(getConfig().getString("spawn.world", "mw_spawn"))) {
            e.setCancelled(true);
            return;
        }
        Byte marker = tnt.getPersistentDataContainer().get(specialTntKey, PersistentDataType.BYTE);
        if (marker == null || marker != (byte)1) return;
        e.setCancelled(true);
        float power = (float)Math.max(1.0, Math.min(12.0, getConfig().getDouble("special-tnt.power", 5.0)));
        boolean breakBlocks = getConfig().getBoolean("special-tnt.break-blocks", true);
        tnt.getWorld().createExplosion(tnt.getLocation(), power, false, breakBlocks);
    }

    // -------- Auction house --------

    private void openAuctionMenu(Player p, int page) {
        AuctionMenu menu = new AuctionMenu(page);
        Inventory inv = menu.getInventory();
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta(); fillerMeta.setDisplayName(" "); filler.setItemMeta(fillerMeta);
        for (int i = 45; i < 54; i++) inv.setItem(i, filler);

        var section = data.getConfigurationSection("auctions");
        List<String> ids = new ArrayList<>();
        if (section != null) ids.addAll(section.getKeys(false));
        ids.sort((a,b) -> Long.compare(parseAuctionId(b), parseAuctionId(a)));
        int from = Math.min(menu.page() * 45, ids.size());
        int to = Math.min(from + 45, ids.size());
        int slot = 0;
        for (String id : ids.subList(from, to)) {
            ItemStack stored = data.getItemStack("auctions." + id + ".item");
            if (stored == null || stored.getType().isAir()) continue;
            ItemStack display = stored.clone();
            ItemMeta meta = display.getItemMeta();
            List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
            lore.add(color("&8----------------"));
            lore.add(color("&7Продавец: &f" + data.getString("auctions." + id + ".seller-name", "Неизвестно")));
            lore.add(color("&7Цена: &e" + money(data.getDouble("auctions." + id + ".price", 0))));
            lore.add(color("&bНажми, чтобы купить"));
            meta.setLore(lore);
            meta.getPersistentDataContainer().set(auctionIdKey, PersistentDataType.STRING, id);
            display.setItemMeta(meta);
            inv.setItem(slot++, display);
        }
        ItemStack prev = new ItemStack(Material.ARROW);
        ItemMeta pm = prev.getItemMeta(); pm.setDisplayName(color("&bПредыдущая страница")); prev.setItemMeta(pm); inv.setItem(45, prev);
        ItemStack info = new ItemStack(Material.BOOK);
        ItemMeta im = info.getItemMeta(); im.setDisplayName(color("&bАукцион MagicWorld"));
        im.setLore(List.of(color("&7Страница: &f"+(menu.page()+1)), color("&7Лотов: &f"+ids.size()), color("&7Продать предмет: &b/ah sell <цена>"), color("&7Снять лот: &b/ah cancel <ID>")));
        info.setItemMeta(im); inv.setItem(49, info);
        ItemStack next = new ItemStack(Material.ARROW);
        ItemMeta nm = next.getItemMeta(); nm.setDisplayName(color("&bСледующая страница")); next.setItemMeta(nm); inv.setItem(53, next);
        p.openInventory(inv);
    }

    private long parseAuctionId(String id) {
        try { return Long.parseLong(id); } catch (NumberFormatException ex) { return -1L; }
    }

    private boolean hasInventorySpace(Player p, ItemStack item) {
        Inventory temporary = Bukkit.createInventory(null, 36);
        temporary.setContents(p.getInventory().getStorageContents());
        return temporary.addItem(item.clone()).isEmpty();
    }

    private void buyAuctionLot(Player p, String id) {
        String path = "auctions." + id;
        ItemStack item = data.getItemStack(path + ".item");
        if (item == null || item.getType().isAir()) { p.sendMessage(color("&cЛот уже недоступен.")); return; }
        UUID seller;
        try { seller = UUID.fromString(data.getString(path + ".seller", "")); }
        catch (IllegalArgumentException ex) { p.sendMessage(color("&cУ лота повреждены данные продавца.")); return; }
        if (seller.equals(p.getUniqueId())) { p.sendMessage(color("&cНельзя купить собственный лот.")); return; }
        double price = data.getDouble(path + ".price", -1);
        if (!Double.isFinite(price) || price < 0 || getBalance(p.getUniqueId()) + 0.0001 < price) {
            p.sendMessage(color("&cНедостаточно средств: &e" + money(Math.max(0, price)))); return;
        }
        if (!hasInventorySpace(p, item)) { p.sendMessage(color("&cОсвободи место в инвентаре перед покупкой.")); return; }
        p.getInventory().addItem(item.clone());
        setBalance(p.getUniqueId(), getBalance(p.getUniqueId()) - price);
        setBalance(seller, getBalance(seller) + price);
        data.set(path, null); savePlayerData();
        p.sendMessage(color("&aПокупка лота &b#" + id + " &aзавершена за &e" + money(price) + "&a."));
        Player onlineSeller = Bukkit.getPlayer(seller);
        if (onlineSeller != null) onlineSeller.sendMessage(color("&aТвой лот &b#" + id + " &aкупили за &e" + money(price) + "&a."));
    }

    private void handleAuction(Player p, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) { openAuctionMenu(p, 0); return; }
        if (args[0].equalsIgnoreCase("sell")) {
            if (args.length < 2) { p.sendMessage(color("&cИспользование: /ah sell <цена>")); return; }
            double price; try { price = Double.parseDouble(args[1].replace(',', '.')); } catch (NumberFormatException ex) { price = -1; }
            if (!Double.isFinite(price) || price < 1 || price > 1_000_000_000) { p.sendMessage(color("&cЦена должна быть от 1 до 1 000 000 000.")); return; }
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (hand.getType().isAir() || isSphere(hand) || isMagicTnt(hand)) { p.sendMessage(color("&cЭтот предмет нельзя выставить.")); return; }
            int activeLots = 0;
            var auctionSection = data.getConfigurationSection("auctions");
            if (auctionSection != null) for (String lotId : auctionSection.getKeys(false))
                if (p.getUniqueId().toString().equals(data.getString("auctions." + lotId + ".seller"))) activeLots++;
            int maxLots = Math.max(1, getConfig().getInt("auction.max-listings-per-player", 5));
            if (activeLots >= maxLots) { p.sendMessage(color("&cДостигнут лимит лотов: " + maxLots + ".")); return; }
            long id = data.getLong("auction-next-id", 1L);
            data.set("auction-next-id", id + 1);
            data.set("auctions." + id + ".seller", p.getUniqueId().toString());
            data.set("auctions." + id + ".seller-name", p.getName());
            data.set("auctions." + id + ".price", Math.round(price * 100.0) / 100.0);
            data.set("auctions." + id + ".item", hand.clone());
            p.getInventory().setItemInMainHand(null);
            savePlayerData();
            p.sendMessage(color("&aЛот &b#" + id + " &aвыставлен за &e" + money(price) + "&a."));
            openAuctionMenu(p, 0); return;
        }
        if (args[0].equalsIgnoreCase("buy")) {
            if (args.length < 2) { p.sendMessage(color("&cИспользование: /ah buy <ID>")); return; }
            buyAuctionLot(p, args[1]); return;
        }
        if (args[0].equalsIgnoreCase("cancel")) {
            if (args.length < 2) { p.sendMessage(color("&cИспользование: /ah cancel <ID>")); return; }
            String path = "auctions." + args[1];
            String owner = data.getString(path + ".seller", "");
            ItemStack item = data.getItemStack(path + ".item");
            if (!p.getUniqueId().toString().equals(owner) || item == null) { p.sendMessage(color("&cЭто не твой лот или он уже продан.")); return; }
            Map<Integer, ItemStack> overflow = p.getInventory().addItem(item.clone());
            overflow.values().forEach(drop -> p.getWorld().dropItemNaturally(p.getLocation(), drop));
            data.set(path, null); savePlayerData(); p.sendMessage(color("&aЛот снят, предмет возвращён.")); return;
        }
        p.sendMessage(color("&7/ah &8— открыть GUI, &b/ah sell <цена> &8— продать, &b/ah buy <ID> &8— купить, &b/ah cancel <ID> &8— снять."));
    }

    // -------- Clans --------

    private String clanPath(UUID player) {
        var clans = data.getConfigurationSection("clans");
        if (clans == null) return null;
        for (String name : clans.getKeys(false)) {
            List<String> members = data.getStringList("clans." + name + ".members");
            if (members.contains(player.toString())) return "clans." + name;
        }
        return null;
    }

    private void handleClan(Player p, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("info")) {
            String path = clanPath(p.getUniqueId());
            if (path == null) { p.sendMessage(color("&7Ты не состоишь в клане. Создать: &b/clan create <название>")); return; }
            String name = path.substring("clans.".length());
            p.sendMessage(color("&b&lКЛАН " + name + " &8— &7участники: &f" + data.getStringList(path + ".members").size()));
            p.sendMessage(color("&7Глава: &f" + data.getString(path + ".leader-name", "?")));
            p.sendMessage(color("&7Состав: &f" + String.join(", ", data.getStringList(path + ".member-names"))));
            p.sendMessage(color("&7Банк клана: &b" + money(data.getDouble(path + ".bank", 0))));
            p.sendMessage(color("&7Заместители: &f" + String.join(", ", data.getStringList(path + ".officer-names"))));
            return;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("create")) {
            if (args.length < 2 || !args[1].matches("[A-Za-z0-9_]{3,16}")) { p.sendMessage(color("&cНазвание: 3–16 символов, латиница, цифры и _.")); return; }
            if (clanPath(p.getUniqueId()) != null) { p.sendMessage(color("&cТы уже состоишь в клане.")); return; }
            String name = args[1].toLowerCase(Locale.ROOT), path = "clans." + name;
            if (data.contains(path)) { p.sendMessage(color("&cТакой клан уже существует.")); return; }
            data.set(path + ".leader", p.getUniqueId().toString()); data.set(path + ".leader-name", p.getName());
            data.set(path + ".members", List.of(p.getUniqueId().toString())); data.set(path + ".member-names", List.of(p.getName()));
            data.set(path + ".officers", new ArrayList<String>()); data.set(path + ".officer-names", new ArrayList<String>()); data.set(path + ".bank", 0.0);
            savePlayerData(); p.sendMessage(color("&aКлан &b" + name + " &aсоздан.")); return;
        }
        if (sub.equals("join")) {
            if (args.length < 2) { p.sendMessage(color("&cИспользование: /clan join <название>")); return; }
            if (clanPath(p.getUniqueId()) != null) { p.sendMessage(color("&cСначала выйди из текущего клана.")); return; }
            String name = args[1].toLowerCase(Locale.ROOT), path = "clans." + name;
            if (!data.getBoolean("clan-invites." + p.getUniqueId() + "." + name, false) || !data.contains(path)) { p.sendMessage(color("&cНет приглашения в этот клан.")); return; }
            List<String> members = data.getStringList(path + ".members"); members.add(p.getUniqueId().toString()); data.set(path + ".members", members);
            List<String> names = data.getStringList(path + ".member-names"); names.add(p.getName()); data.set(path + ".member-names", names);
            data.set("clan-invites." + p.getUniqueId() + "." + name, null); savePlayerData(); p.sendMessage(color("&aТы вступил в клан &b" + name + "&a.")); return;
        }
        String path = clanPath(p.getUniqueId());
        if (path == null) { p.sendMessage(color("&cТы не состоишь в клане.")); return; }
        String name = path.substring("clans.".length());
        boolean leader = p.getUniqueId().toString().equals(data.getString(path + ".leader"));
        boolean officer = data.getStringList(path + ".officers").contains(p.getUniqueId().toString());
        if (sub.equals("bank")) {
            p.sendMessage(color("&bБанк клана: &e" + money(data.getDouble(path + ".bank", 0)))); return;
        }
        if (sub.equals("deposit") || sub.equals("withdraw")) {
            if (args.length < 2) { p.sendMessage(color("&cИспользование: /clan " + sub + " <сумма>")); return; }
            double amount; try { amount = Double.parseDouble(args[1].replace(',', '.')); } catch (NumberFormatException ex) { amount = -1; }
            amount = Math.floor(amount * 100.0) / 100.0;
            if (!Double.isFinite(amount) || amount < 0.01) { p.sendMessage(color("&cУкажи сумму больше 0.")); return; }
            double bank = data.getDouble(path + ".bank", 0);
            if (sub.equals("deposit")) {
                if (getBalance(p.getUniqueId()) < amount) { p.sendMessage(color("&cНедостаточно монет.")); return; }
                setBalance(p.getUniqueId(), getBalance(p.getUniqueId()) - amount); data.set(path + ".bank", bank + amount);
                p.sendMessage(color("&aВнесено в банк клана: &e" + money(amount)));
            } else {
                if (!leader) { p.sendMessage(color("&cСнимать деньги из банка может только глава.")); return; }
                if (bank < amount) { p.sendMessage(color("&cВ банке клана недостаточно средств.")); return; }
                data.set(path + ".bank", bank - amount); setBalance(p.getUniqueId(), getBalance(p.getUniqueId()) + amount);
                p.sendMessage(color("&aСнято из банка клана: &e" + money(amount)));
            }
            savePlayerData(); return;
        }
        if (sub.equals("promote") || sub.equals("demote")) {
            if (!leader || args.length < 2) { p.sendMessage(color("&cИзменять роли может только глава. /clan promote|demote <игрок>")); return; }
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
            String uuid = target.getUniqueId().toString();
            if (!data.getStringList(path + ".members").contains(uuid) || uuid.equals(data.getString(path + ".leader"))) { p.sendMessage(color("&cУчастник не найден или является главой.")); return; }
            List<String> officers = data.getStringList(path + ".officers");
            List<String> officerNames = data.getStringList(path + ".officer-names");
            if (sub.equals("promote")) { if (!officers.contains(uuid)) officers.add(uuid); if (target.getName()!=null && !officerNames.contains(target.getName())) officerNames.add(target.getName()); }
            else { officers.remove(uuid); if (target.getName()!=null) officerNames.remove(target.getName()); }
            data.set(path + ".officers", officers); data.set(path + ".officer-names", officerNames); savePlayerData();
            p.sendMessage(color("&aРоль участника обновлена.")); return;
        }
        if (sub.equals("invite")) {
            if (!leader && !officer) { p.sendMessage(color("&cПриглашать могут глава и заместители.")); return; }
            if (args.length < 2) { p.sendMessage(color("&cИспользование: /clan invite <игрок>")); return; }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null || clanPath(target.getUniqueId()) != null) { p.sendMessage(color("&cИгрок не найден или уже состоит в клане.")); return; }
            data.set("clan-invites." + target.getUniqueId() + "." + name, true); savePlayerData();
            target.sendMessage(color("&aТебя пригласили в клан &b" + name + "&a. Вступить: &b/clan join " + name));
            p.sendMessage(color("&aПриглашение отправлено.")); return;
        }
        if (sub.equals("leave")) {
            if (leader) { p.sendMessage(color("&cГлава не может выйти. Используй /clan disband.")); return; }
            removeClanMember(path, p.getUniqueId().toString(), p.getName()); savePlayerData(); p.sendMessage(color("&7Ты вышел из клана.")); return;
        }
        if (sub.equals("kick")) {
            if ((!leader && !officer) || args.length < 2) { p.sendMessage(color("&cИсключать могут глава и заместители. /clan kick <игрок>")); return; }
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
            if (!data.getStringList(path + ".members").contains(target.getUniqueId().toString()) || target.getUniqueId().equals(p.getUniqueId()) || (!leader && (target.getUniqueId().toString().equals(data.getString(path + ".leader")) || data.getStringList(path + ".officers").contains(target.getUniqueId().toString())))) { p.sendMessage(color("&cУчастник не найден.")); return; }
            removeClanMember(path, target.getUniqueId().toString(), target.getName()); savePlayerData(); p.sendMessage(color("&aУчастник исключён.")); return;
        }
        if (sub.equals("disband")) {
            if (!leader) { p.sendMessage(color("&cРаспустить клан может только глава.")); return; }
            data.set(path, null); savePlayerData(); p.sendMessage(color("&cКлан распущен.")); return;
        }
        p.sendMessage(color("&7/clan create <имя> | invite <ник> | join <имя> | bank | deposit <сумма> | withdraw <сумма>"));
        p.sendMessage(color("&7/clan promote <ник> | demote <ник> | info | leave | kick <ник> | disband"));
    }

    private void removeClanMember(String path, String uuid, String playerName) {
        List<String> members = data.getStringList(path + ".members"); members.remove(uuid); data.set(path + ".members", members);
        List<String> names = data.getStringList(path + ".member-names"); if (playerName != null) names.remove(playerName); data.set(path + ".member-names", names);
        List<String> officers = data.getStringList(path + ".officers"); officers.remove(uuid); data.set(path + ".officers", officers);
        List<String> officerNames = data.getStringList(path + ".officer-names"); if (playerName != null) officerNames.remove(playerName); data.set(path + ".officer-names", officerNames);
    }

    // -------- Persistent economy, homes, warps and utility commands --------

    private void loadPlayerData() {
        dataFile = new File(getDataFolder(), "data.yml");
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    private void savePlayerData() {
        if (data == null || dataFile == null) return;
        try { data.save(dataFile); }
        catch (IOException ex) { getLogger().severe("Не удалось сохранить data.yml: " + ex.getMessage()); }
    }

    private double getBalance(UUID uuid) {
        return Math.max(0, data.getDouble("accounts." + uuid, getConfig().getDouble("economy.start-balance", 1000.0)));
    }

    private void setBalance(UUID uuid, double amount) {
        data.set("accounts." + uuid, Math.max(0, Math.round(amount * 100.0) / 100.0));
    }

    private String money(double amount) {
        return String.format(Locale.US, "%.2f", amount) + " " + getConfig().getString("economy.currency", "монет");
    }

    private boolean validName(String name) { return name.matches("[A-Za-z0-9_-]{1,16}"); }

    private void storeLocation(String path, Location loc) {
        data.set(path + ".world", loc.getWorld().getName());
        data.set(path + ".x", loc.getX()); data.set(path + ".y", loc.getY()); data.set(path + ".z", loc.getZ());
        data.set(path + ".yaw", loc.getYaw()); data.set(path + ".pitch", loc.getPitch());
        savePlayerData();
    }

    private Location readLocation(String path) {
        String worldName = data.getString(path + ".world");
        if (worldName == null) return null;
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(world, data.getDouble(path + ".x"), data.getDouble(path + ".y"), data.getDouble(path + ".z"),
                (float)data.getDouble(path + ".yaw"), (float)data.getDouble(path + ".pitch"));
    }

    private void openShop(Player p) {
        ShopMenu menu = new ShopMenu();
        Inventory inv = menu.getInventory();
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta(); fm.setDisplayName(" "); filler.setItemMeta(fm);
        for (int i=0;i<27;i++) inv.setItem(i, filler);
        Material[] items = {Material.ENDER_PEARL, Material.GOLDEN_APPLE, Material.DIAMOND, Material.EXPERIENCE_BOTTLE, Material.TOTEM_OF_UNDYING};
        int[] slots = {10,12,14,16,22};
        for (int i=0;i<items.length;i++) {
            Material material=items[i]; double price=Math.max(0.0,getConfig().getDouble("shop.prices."+material.name().toLowerCase(Locale.ROOT),100.0));
            int amount=material==Material.TOTEM_OF_UNDYING?1:8;
            ItemStack item=new ItemStack(material,amount); ItemMeta meta=item.getItemMeta();
            meta.setDisplayName(color("&b"+material.name().replace('_',' ')));
            meta.setLore(List.of(color("&7Количество: &f"+amount),color("&7Цена: &b"+money(price)),color("&eНажми, чтобы купить")));
            item.setItemMeta(meta); inv.setItem(slots[i],item);
        }
        p.openInventory(inv);
    }

    private void saveHome(Player p, String name) {
        if (!validName(name)) { p.sendMessage(color("&cИмя должно быть 1–16 символов: латиница, цифры, _ или -.")); return; }
        storeLocation("homes."+p.getUniqueId()+"."+name.toLowerCase(Locale.ROOT),p.getLocation());
        p.sendMessage(color("&bMagicWorld &8» &aДом &b"+name+" &aсохранён."));
    }

    private void teleportToSaved(Player p, String path, String label) {
        Location loc=readLocation(path);
        if (loc==null) { p.sendMessage(color("&bMagicWorld &8» &cТочка не найдена или её мир не загружен.")); return; }
        safeTeleport(p,loc,false);
    }

    private void sendHelp(Player p) {
        p.sendMessage(color("&b&lMagicWorld &8» &7Команды игрока:"));
        p.sendMessage(color("&b/spawn &7/ &b/rtp &7/ &b/home &7/ &b/sethome &7/ &b/delhome"));
        p.sendMessage(color("&b/tpa <игрок> &7/ &b/tpaccept &7/ &b/tpdeny"));
        p.sendMessage(color("&b/balance &7/ &b/pay <игрок> <сумма> &7/ &b/shop &7/ &b/ah"));
        p.sendMessage(color("&b/warp <имя> &7/ &b/ec &7/ &b/repair &7/ &b/talisman"));
        p.sendMessage(color("&b/ah &7— аукцион, &b/clan &7— кланы, &b/daily &7— награда, &b/quest &7— задание."));
        p.sendMessage(color("&7Админ: &b/mw tnt <игрок> <1-64> &7— выдать магический TNT."));
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!playerOnly(sender)) return true;
        Player p = (Player)sender;
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "mw" -> {
                if (args.length == 0 || args[0].equalsIgnoreCase("info")) p.sendMessage(msg("admin-help"));
                else if (args[0].equalsIgnoreCase("reload")) {
                    if (!admin(p)) return true;
                    reloadConfig(); tell(p, "spawn-set");
                } else if (args[0].equalsIgnoreCase("hub")) {
                    if (!admin(p)) return true;
                    World w = Bukkit.getWorld(getConfig().getString("spawn.world", "mw_spawn"));
                    if (w == null) { p.sendMessage(color("&cМир спавна не загружен.")); return true; }
                    p.teleportAsync(new Location(w, 80.5, Math.max(w.getHighestBlockYAt(80,95)+1, 68), 95.5));
                } else if (args[0].equalsIgnoreCase("tnt")) {
                    if (!admin(p)) return true;
                    if (args.length < 3) { p.sendMessage(color("&cИспользование: /mw tnt <игрок> <1-64>")); return true; }
                    Player target = Bukkit.getPlayerExact(args[1]);
                    int amount;
                    try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException ex) { amount = 0; }
                    if (target == null || amount < 1 || amount > 64) { p.sendMessage(color("&cИгрок не найден или количество должно быть 1–64.")); return true; }
                    Map<Integer, ItemStack> overflow = target.getInventory().addItem(createMagicTnt(amount));
                    overflow.values().forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
                    p.sendMessage(color("&aВыдано &b" + amount + " &aмагических TNT игроку &b" + target.getName() + "&a."));
                    target.sendMessage(color("&bТы получил магический TNT от администрации."));
                } else if (args[0].equalsIgnoreCase("sphere")) {
                    if (!admin(p)) return true;
                    if (args.length < 3) { p.sendMessage(color("&cИспользование: /mw sphere <игрок> <количество>")); return true; }
                    Player target = Bukkit.getPlayerExact(args[1]);
                    if (target == null) { tell(p, "talisman-invalid-player"); return true; }
                    int amount;
                    try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException ex) { amount = 0; }
                    if (amount < 1 || amount > 64) { tell(p, "talisman-invalid-amount"); return true; }
                    HashMap<Integer, ItemStack> overflow = target.getInventory().addItem(createSphere(amount));
                    overflow.values().forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
                    tell(p, "talisman-admin-give", "amount", String.valueOf(amount));
                    p.sendMessage(color("&7Игрок: &b" + target.getName()));
                    tell(target, "talisman-received", "amount", String.valueOf(amount));
                } else p.sendMessage(msg("admin-help"));
            }
            case "setspawn" -> {
                if (!admin(p)) return true;
                Location l = p.getLocation();
                getConfig().set("spawn.world", l.getWorld().getName());
                getConfig().set("spawn.x", l.getX()); getConfig().set("spawn.y", l.getY());
                getConfig().set("spawn.z", l.getZ()); getConfig().set("spawn.yaw", l.getYaw());
                getConfig().set("spawn.pitch", l.getPitch()); saveConfig();
                tell(p, "spawn-set");
            }
            case "spawn" -> {
                if (!p.hasPermission("magicworld.spawn") && !p.hasPermission("magicworld.admin")) { tell(p, "no-permission"); return true; }
                Location loc = spawnLocation();
                if (loc == null) tell(p, "spawn-missing"); else safeTeleport(p, loc, false);
            }
            case "rtp" -> {
                if (!p.hasPermission("magicworld.rtp") && !p.hasPermission("magicworld.admin")) { tell(p, "no-permission"); return true; }
                long now = System.currentTimeMillis(), until = rtpCooldown.getOrDefault(p.getUniqueId(), 0L);
                if (until > now) { tell(p, "rtp-cooldown", "seconds", String.valueOf((until-now+999)/1000)); return true; }
                World world = Bukkit.getWorld(getConfig().getString("survival.world", "world"));
                if (world == null) { tell(p, "rtp-world-missing"); return true; }
                Location target = findSafeLocation(world);
                if (target == null) { tell(p, "rtp-failed"); return true; }
                rtpCooldown.put(p.getUniqueId(), now + getConfig().getLong("rtp.cooldown-seconds", 90) * 1000L);
                safeTeleport(p, target, inSpawn(p));
            }
            case "talisman" -> {
                if (!p.hasPermission("magicworld.talisman") && !p.hasPermission("magicworld.admin")) { tell(p, "no-permission"); return true; }
                openTalismanMenu(p);
            }
            case "daily" -> claimDaily(p);
            case "quest" -> handleDailyQuest(p, args);
            case "balance" -> {
                Player target = args.length > 0 ? Bukkit.getPlayerExact(args[0]) : p;
                if (target == null) { p.sendMessage(color("&cИгрок должен быть онлайн.")); return true; }
                p.sendMessage(color("&bMagicWorld &8» &7Баланс " + (target.equals(p) ? "" : target.getName()+": ") + "&b" + money(getBalance(target.getUniqueId()))));
            }
            case "pay" -> {
                if (args.length < 2) { p.sendMessage(color("&cИспользование: /pay <игрок> <сумма>")); return true; }
                Player target=Bukkit.getPlayerExact(args[0]);
                if (target==null || target.equals(p)) { p.sendMessage(color("&cУкажи другого игрока, который сейчас онлайн.")); return true; }
                double amount; try { amount=Double.parseDouble(args[1].replace(',','.')); } catch(NumberFormatException ex) { amount=0; }
                amount=Math.floor(amount*100.0)/100.0;
                if (!Double.isFinite(amount) || amount<0.01) { p.sendMessage(color("&cСумма должна быть не меньше 0.01.")); return true; }
                if (getBalance(p.getUniqueId())<amount) { p.sendMessage(color("&cНедостаточно средств.")); return true; }
                setBalance(p.getUniqueId(),getBalance(p.getUniqueId())-amount);
                setBalance(target.getUniqueId(),getBalance(target.getUniqueId())+amount); savePlayerData();
                p.sendMessage(color("&aТы перевёл &b"+money(amount)+" &aигроку &b"+target.getName()+"."));
                target.sendMessage(color("&aТы получил &b"+money(amount)+" &aот &b"+p.getName()+"."));
            }
            case "sethome" -> saveHome(p,args.length>0?args[0]:"home");
            case "home" -> {
                String name=args.length>0?args[0].toLowerCase(Locale.ROOT):"home";
                if(!validName(name)){p.sendMessage(color("&cНекорректное имя дома."));return true;}
                teleportToSaved(p,"homes."+p.getUniqueId()+"."+name,"дом");
            }
            case "delhome" -> {
                if(args.length<1){p.sendMessage(color("&cИспользование: /delhome <имя>"));return true;}
                if(!validName(args[0])){p.sendMessage(color("&cНекорректное имя дома."));return true;}
                data.set("homes."+p.getUniqueId()+"."+args[0].toLowerCase(Locale.ROOT),null); savePlayerData();
                p.sendMessage(color("&aДом удалён, если он существовал."));
            }
            case "tpa" -> {
                if(args.length<1){p.sendMessage(color("&cИспользование: /tpa <игрок>"));return true;}
                Player target=Bukkit.getPlayerExact(args[0]);
                if(target==null||target.equals(p)){p.sendMessage(color("&cИгрок не найден или указан ты сам."));return true;}
                tpaRequests.put(target.getUniqueId(),new TpaRequest(p.getUniqueId(),System.currentTimeMillis()));
                p.sendMessage(color("&aЗапрос отправлен игроку &b"+target.getName()+"&a."));
                target.sendMessage(color("&b"+p.getName()+" &7хочет телепортироваться к тебе. &a/tpaccept &7или &c/tpdeny"));
            }
            case "tpaccept" -> {
                TpaRequest req=tpaRequests.remove(p.getUniqueId());
                if(req==null||System.currentTimeMillis()-req.createdAt()>60000){p.sendMessage(color("&cНет активных запросов на телепортацию."));return true;}
                Player requester=Bukkit.getPlayer(req.requester());
                if(requester==null){p.sendMessage(color("&cИгрок уже вышел с сервера."));return true;}
                safeTeleport(requester,p.getLocation(),false);
                p.sendMessage(color("&aЗапрос принят."));
            }
            case "tpdeny" -> {
                TpaRequest req=tpaRequests.remove(p.getUniqueId());
                if(req==null){p.sendMessage(color("&cНет активных запросов."));return true;}
                Player requester=Bukkit.getPlayer(req.requester());
                if(requester!=null) requester.sendMessage(color("&cТвой запрос отклонён."));
                p.sendMessage(color("&7Запрос отклонён."));
            }
            case "setwarp" -> {
                if(!admin(p))return true;
                if(args.length<1||!validName(args[0])){p.sendMessage(color("&cИспользование: /setwarp <имя>"));return true;}
                storeLocation("warps."+args[0].toLowerCase(Locale.ROOT),p.getLocation());
                p.sendMessage(color("&aВарп &b"+args[0]+" &aсохранён."));
            }
            case "delwarp" -> {
                if(!admin(p))return true;
                if(args.length<1){p.sendMessage(color("&cИспользование: /delwarp <имя>"));return true;}
                data.set("warps."+args[0].toLowerCase(Locale.ROOT),null);savePlayerData();p.sendMessage(color("&aВарп удалён, если он существовал."));
            }
            case "warp" -> {
                if(args.length<1){p.sendMessage(color("&cИспользование: /warp <имя>"));return true;}
                if(!validName(args[0])){p.sendMessage(color("&cНекорректное имя варпа."));return true;}
                teleportToSaved(p,"warps."+args[0].toLowerCase(Locale.ROOT),"варп");
            }
            case "ec" -> p.openInventory(p.getEnderChest());
            case "repair" -> {
                ItemStack hand=p.getInventory().getItemInMainHand();
                if(hand.getType().isAir()||!(hand.getItemMeta() instanceof Damageable)){p.sendMessage(color("&cВ руке нет ремонтируемого предмета."));return true;}
                Damageable dmg=(Damageable)hand.getItemMeta();
                if(dmg.getDamage()<=0){p.sendMessage(color("&eПредмет уже полностью починен."));return true;}
                double cost=Math.max(0.0,getConfig().getDouble("repair.cost",500.0));
                if(getBalance(p.getUniqueId())<cost){p.sendMessage(color("&cРемонт стоит &b"+money(cost)+"&c."));return true;}
                dmg.setDamage(0);hand.setItemMeta((ItemMeta)dmg);setBalance(p.getUniqueId(),getBalance(p.getUniqueId())-cost);savePlayerData();
                p.sendMessage(color("&aПредмет починен за &b"+money(cost)+"&a."));
            }
            case "shop" -> openShop(p);
            case "ah" -> handleAuction(p, args);
            case "clan" -> handleClan(p, args);
        }
        return true;
    }

    private void claimDaily(Player p) {
        if (!getConfig().getBoolean("daily-reward.enabled", true)) { p.sendMessage(color("&cЕжедневная награда отключена.")); return; }
        long now = System.currentTimeMillis();
        long next = data.getLong("daily.next-claim." + p.getUniqueId(), 0L);
        long cooldown = Math.max(1, getConfig().getLong("daily-reward.cooldown-hours", 24)) * 3_600_000L;
        if (now < next) { long mins = Math.max(1, (next - now + 59_999) / 60_000); p.sendMessage(color("&7Следующая ежедневная награда через &b" + (mins/60) + " ч. " + (mins%60) + " мин.")); return; }
        double reward = Math.max(0, getConfig().getDouble("daily-reward.amount", 750));
        setBalance(p.getUniqueId(), getBalance(p.getUniqueId()) + reward);
        data.set("daily.next-claim." + p.getUniqueId(), now + cooldown); savePlayerData();
        p.sendMessage(color("&aЕжедневная награда получена: &e" + money(reward) + "&a."));
    }

    private void handleDailyQuest(Player p, String[] args) {
        String base = "quests." + p.getUniqueId();
        String today = java.time.LocalDate.now().toString();
        if (!today.equals(data.getString(base + ".day", ""))) { data.set(base + ".day", today); data.set(base + ".kills", 0); data.set(base + ".claimed", false); }
        int goal = Math.max(1, getConfig().getInt("daily-quest.mob-kills", 10));
        int kills = data.getInt(base + ".kills", 0);
        if (args.length > 0 && args[0].equalsIgnoreCase("claim")) {
            if (data.getBoolean(base + ".claimed", false)) { p.sendMessage(color("&cНаграда за задание уже получена сегодня.")); return; }
            if (kills < goal) { p.sendMessage(color("&cУбей ещё &b" + (goal-kills) + " &cвраждебных мобов.")); return; }
            double reward = Math.max(0, getConfig().getDouble("daily-quest.reward", 1200));
            setBalance(p.getUniqueId(), getBalance(p.getUniqueId()) + reward); data.set(base + ".claimed", true); savePlayerData();
            p.sendMessage(color("&aЗадание выполнено! Награда: &e" + money(reward))); return;
        }
        p.sendMessage(color("&b&lЕЖЕДНЕВНОЕ ЗАДАНИЕ"));
        p.sendMessage(color("&7Убей враждебных мобов: &b" + Math.min(kills, goal) + "/" + goal));
        p.sendMessage(color(data.getBoolean(base + ".claimed", false) ? "&aНаграда уже получена." : "&7Награда: &e" + money(getConfig().getDouble("daily-quest.reward", 1200)) + " &8— &b/quest claim"));
    }

    private Location findSafeLocation(World world) {
        int min = Math.max(0, getConfig().getInt("rtp.min-radius", 1500));
        int max = Math.max(min + 1, getConfig().getInt("rtp.max-radius", 8000));
        int attempts = Math.max(1, getConfig().getInt("rtp.attempts", 60));
        WorldBorder border = world.getWorldBorder();
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int i = 0; i < attempts; i++) {
            double angle = random.nextDouble(0, Math.PI * 2), radius = random.nextDouble(min, max);
            int x = (int)Math.round(Math.cos(angle) * radius), z = (int)Math.round(Math.sin(angle) * radius);
            if (!border.isInside(new Location(world, x, world.getMinHeight(), z))) continue;
            int y = world.getHighestBlockYAt(x, z);
            if (y < world.getMinHeight() || y + 2 >= world.getMaxHeight()) continue;
            Material floor = world.getBlockAt(x, y, z).getType();
            Material feet = world.getBlockAt(x, y + 1, z).getType();
            Material head = world.getBlockAt(x, y + 2, z).getType();
            if (!floor.isSolid() || !feet.isAir() || !head.isAir()) continue;
            if (getConfig().getBoolean("rtp.avoid-water", true) && (floor == Material.WATER || floor == Material.LAVA)) continue;
            return new Location(world, x + .5, y + 1, z + .5);
        }
        return null;
    }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("mw") && args.length == 1)
            return List.of("info", "hub", "sphere", "tnt", "reload").stream().filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        return Collections.emptyList();
    }
}
